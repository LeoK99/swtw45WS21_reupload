package com.buschmais.adronlineeditor.vaadin;

import com.buschmais.adronlineeditor.adreditor.ADR;
import com.buschmais.adronlineeditor.adreditor.ADRController;
import com.vaadin.flow.component.ClickEvent;
import com.vaadin.flow.component.ComponentEventListener;
import com.vaadin.flow.component.button.Button;
import com.vaadin.flow.component.grid.Grid;
import com.vaadin.flow.component.html.H2;
import com.vaadin.flow.component.html.H3;
import com.vaadin.flow.component.orderedlayout.HorizontalLayout;
import com.vaadin.flow.component.orderedlayout.VerticalLayout;
import com.vaadin.flow.router.Route;

@Route("adrlist")
public class ADRList extends VerticalLayout {
    private final ADRController adrController;

    private VerticalLayout headingLayout;
    private HorizontalLayout headingLayoutLeft;
    private HorizontalLayout headingLayoutRight;

    private final Grid<ADR> adrGrid;

    public ADRList(ADRController adrController){

        /* Instance-Variables */
        this.adrController = adrController;
        this.adrGrid = new Grid<>(ADR.class);

        this.headingLayoutLeft = new HorizontalLayout();
        this.headingLayoutRight = new HorizontalLayout();

        /* Heading */
        H2 heading = new H2("Liste aller Architecture Decision Records");
        add(this.headingLayout);

        /* Navigation-Buttons */
        Button home = new Button("Home");
        Button adrCreate = new Button("ADR erstellen");
        Button deleteADR = new Button("ADR löschen");

        // Action-Listener
        home.addClickListener(new ComponentEventListener<ClickEvent<Button>>() {
            @Override
            public void onComponentEvent(ClickEvent<Button> buttonClickEvent) {
                home.getUI().get().navigate("");
            }
        });

        adrCreate.addClickListener(new ComponentEventListener<ClickEvent<Button>>() {
            @Override
            public void onComponentEvent(ClickEvent<Button> buttonClickEvent) {
                adrCreate.getUI().get().navigate("addnewadr");
            }
        });

        deleteADR.addClickListener(new ComponentEventListener<ClickEvent<Button>>() {
            @Override
            public void onComponentEvent(ClickEvent<Button> buttonClickEvent) {
                deleteADR.getUI().get().navigate("deleteadr");
            }
        });

        /* adding components */
        this.headingLayoutLeft.add(heading);

        this.add(new VerticalLayout(new H3("Navigation"), new HorizontalLayout(home, adrCreate, deleteADR)));

        this.headingLayout = new VerticalLayout(this.headingLayoutRight, this.headingLayoutLeft);

        listADRs();
    }

    private void listADRs(){
        this.adrGrid.setItems(adrController.getADRs());
        add(adrGrid);
    }
}
