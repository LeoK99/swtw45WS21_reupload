package com.buschmais.adronlineeditor;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication()
public class AdrOnlineEditorApplication {

    public static void main(String[] args) {
        SpringApplication.run(AdrOnlineEditorApplication.class, args);
    }
}
