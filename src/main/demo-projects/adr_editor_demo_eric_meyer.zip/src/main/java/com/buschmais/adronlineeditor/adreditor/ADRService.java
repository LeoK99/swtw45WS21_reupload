package com.buschmais.adronlineeditor.adreditor;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;

import javax.transaction.Transactional;
import java.util.List;
import java.util.Optional;

@Service
public class ADRService {

    private final ADRRepository adrRepository;

    @Autowired
    public ADRService(ADRRepository adrRepository){
        this.adrRepository = adrRepository;
    }

    public List<ADR> getADRs() {
        return adrRepository.findAll();
    }

    public ADR getADR(Long adrId) {
        return adrRepository.findById(adrId).get();
    }

    public void deleteADR(Long adrId) {
        boolean exists = adrRepository.existsById(adrId);
        if(!exists){
            throw new IllegalStateException("ADR with given ID doesn't exist!");
        }

        adrRepository.deleteById(adrId);
    }

    public void addNewADR(ADR adr) {
        adrRepository.save(adr);
    }

    @Transactional
    public void updateADR(Long id, String title, int status, String context, String consequences) {
        boolean exists = adrRepository.existsById(id);
        if(!exists){
            throw new IllegalStateException("ADR with given ID doesn't exist!");
        }
        ADR adr = adrRepository.findById(id).get();

        adr.setTitle(title);
        adr.setStatus(status);
        adr.setContext(context);
        adr.setConsequences(consequences);

    }

}
