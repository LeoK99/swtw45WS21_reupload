package com.buschmais.adronlineeditor.vaadin;

import com.buschmais.adronlineeditor.adreditor.ADRController;
import com.vaadin.flow.component.ClickEvent;
import com.vaadin.flow.component.ComponentEventListener;
import com.vaadin.flow.component.button.Button;
import com.vaadin.flow.component.html.H2;
import com.vaadin.flow.component.html.H3;
import com.vaadin.flow.component.notification.Notification;
import com.vaadin.flow.component.orderedlayout.VerticalLayout;
import com.vaadin.flow.component.textfield.TextField;
import com.vaadin.flow.router.Route;

import java.util.stream.Collectors;

@Route("deleteadr")
public class ADRDelete extends VerticalLayout {

    private final ADRController adrController;

    private String buttonWidth = "400px";

    public ADRDelete(ADRController adrController) {
        this.adrController = adrController;

        setAlignItems(Alignment.CENTER);

        H2 heading = new H2("Löschen einer Architecture Decision Record");
        add(heading);

        TextField deleteId = new TextField("ADR-ID", "1");
        add(deleteId);

        /* Delete-Button */
        Button delete = new Button("Löschen");

        delete.setWidth(this.buttonWidth);
        delete.setHeight("75px");

        // Action-Listener
        delete.addClickListener(new ComponentEventListener<ClickEvent<Button>>() {
            @Override
            public void onComponentEvent(ClickEvent<Button> buttonClickEvent) {

                if (deleteId.getValue().trim().isEmpty()) {
                    Notification.show("Error: " + deleteId.getLabel() + " wurde nicht ausgefüllt!");
                } else {
                    if (!deleteId.getValue().matches("[0-9]*")) {
                        Notification.show("Error: " + deleteId.getLabel() + " darf nur Ziffern enthalten!");
                    } else {

                        Long id = Long.parseLong(deleteId.getValue().trim());
                        if (adrController.getADRs().stream().filter(adr -> adr.getId().equals(id)).collect(Collectors.toList()).size() == 0) {
                            Notification.show("Error: ADR mit der ID: " + id + " wurde nicht gefunden!");

                        } else {
                            adrController.deleteADR(id);
                            Notification.show("ADR mit der ID: " + id + " wurde erfolgreich gelöscht!");
                        }


                    }

                }
            }
        });

        add(delete);

        /* Navigation-Buttons */
        Button home = new Button("Home");
        Button adrList = new Button("ADR-Liste");
        Button adrCreate = new Button("ADR erstellen");

        home.setWidth(this.buttonWidth);
        adrList.setWidth(this.buttonWidth);
        adrCreate.setWidth(this.buttonWidth);

        // ActionListener
        home.addClickListener(new ComponentEventListener<ClickEvent<Button>>() {
            @Override
            public void onComponentEvent(ClickEvent<Button> buttonClickEvent) {
                home.getUI().get().navigate("");
            }
        });

        adrCreate.addClickListener(new ComponentEventListener<ClickEvent<Button>>() {
            @Override
            public void onComponentEvent(ClickEvent<Button> buttonClickEvent) {
                adrCreate.getUI().get().navigate("addnewadr");
            }
        });

        adrList.addClickListener(new ComponentEventListener<ClickEvent<Button>>() {
            @Override
            public void onComponentEvent(ClickEvent<Button> buttonClickEvent) {
                adrList.getUI().get().navigate("adrlist");
            }
        });

        /* Heading */
        H3 navigationLabel = new H3("Navigation");
        add(navigationLabel);

        /* Adding Buttons */
        add(home);
        add(adrList);
        add(adrCreate);
    }
}
