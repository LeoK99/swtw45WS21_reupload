package com.buschmais.adronlineeditor.adreditor;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.Optional;

@Repository
public interface ADRRepository extends JpaRepository<ADR, Long> {

    Optional<ADR> findADRByTitle(String title);

}
