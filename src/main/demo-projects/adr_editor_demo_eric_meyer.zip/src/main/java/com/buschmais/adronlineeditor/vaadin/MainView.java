package com.buschmais.adronlineeditor.vaadin;


import com.buschmais.adronlineeditor.adreditor.ADRController;
import com.vaadin.flow.component.ClickEvent;
import com.vaadin.flow.component.ComponentEventListener;
import com.vaadin.flow.component.button.Button;
import com.vaadin.flow.component.grid.Grid;
import com.vaadin.flow.component.html.H1;
import com.vaadin.flow.component.orderedlayout.VerticalLayout;

import com.vaadin.flow.router.Route;


@Route //Root-View of web application
public class MainView extends VerticalLayout {

    private final ADRController adrController;

    private Grid<Button> linkButtonGrid;

    private Button listAllADR;
    private Button addADR;
    private Button deleteADR;

    private String buttonWidth = "400px";

    private H1 heading;

    public MainView(ADRController adrController) {
        /* Instance-Variables */
        this.adrController = adrController;

        /* View-Configuration */
        setAlignItems(Alignment.CENTER);

        /* Components */
        setComponents();
    }

    private void setComponents() {

        /* Heading */
        this.heading = new H1("ADR-Online Editor");
        add(this.heading);

        /* Buttons */
        // definition
        listAllADR = new Button("ADR-Liste");
        addADR = new Button("ADR hinzufügen");
        deleteADR = new Button("ADR löschen");

        // Width
        listAllADR.setWidth(this.buttonWidth);
        addADR.setWidth(this.buttonWidth);
        deleteADR.setWidth(this.buttonWidth);

        // Action-Listener
        addActionListeners();

        // Adding
        add(listAllADR);
        add(addADR);
        add(deleteADR);
    }

    private void addActionListeners() {
        listAllADR.addClickListener(new ComponentEventListener<ClickEvent<Button>>() {
            @Override
            public void onComponentEvent(ClickEvent<Button> buttonClickEvent) {
                listAllADR.getUI().get().navigate("adrlist");
            }
        });

        addADR.addClickListener(new ComponentEventListener<ClickEvent<Button>>() {
            @Override
            public void onComponentEvent(ClickEvent<Button> buttonClickEvent) {
                addADR.getUI().get().navigate("addnewadr");
            }
        });

        deleteADR.addClickListener(new ComponentEventListener<ClickEvent<Button>>() {
            @Override
            public void onComponentEvent(ClickEvent<Button> buttonClickEvent) {
                deleteADR.getUI().get().navigate("deleteadr");
            }
        });
    }

}
