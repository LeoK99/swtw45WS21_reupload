package com.buschmais.adronlineeditor.adreditor;

public enum ADRStatus {

    UNKNOWN(0, "unknown"),
    PROPOSED(1, "proposed"),
    ACCEPTED(2, "accepted"),
    SUPERSEDED(3, "superseded"),
    DECLINED(4, "declined");

    private final int status;
    private final String name;

    ADRStatus(int status, String name){
        this.status = status;
        this.name = name;
    }

    public int getStatus(){
        return this.status;
    }

    public String getName(){
        return this.name;
    }
}
