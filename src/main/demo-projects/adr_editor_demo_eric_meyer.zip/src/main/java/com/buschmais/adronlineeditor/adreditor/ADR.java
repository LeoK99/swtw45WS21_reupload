package com.buschmais.adronlineeditor.adreditor;

import org.springframework.boot.autoconfigure.EnableAutoConfiguration;

import javax.persistence.*;
import java.util.Objects;

@Entity
@Table
@EnableAutoConfiguration
public class ADR {

    @Id
    @GeneratedValue
    private Long Id;

    private String title;
    private int status;
    private String context;
    private String consequences;

    public ADR() {

    }

    public ADR(String title, int status, String context, String consequences) {
        this.title = title;
        this.status = status;
        this.context = context;
        this.consequences = consequences;
    }

    public Long getId() {
        return Id;
    }

    public void setId(Long id) {
        Id = id;
    }

    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public int getStatus() {
        return status;
    }

    public void setStatus(int status) {
        this.status = status;
    }

    public String getContext() {
        return context;
    }

    public void setContext(String context) {
        this.context = context;
    }

    public String getConsequences() {
        return consequences;
    }

    public void setConsequences(String consequences) {
        this.consequences = consequences;
    }

    @Override
    public String toString() {
        return "ADR{" +
                "Id=" + Id +
                ", title='" + title + '\'' +
                ", status=" + status +
                ", context='" + context + '\'' +
                ", consequences='" + consequences + '\'' +
                '}';
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        ADR adr = (ADR) o;
        return status == adr.status && Objects.equals(Id, adr.Id) && Objects.equals(title, adr.title) && Objects.equals(context, adr.context) && Objects.equals(consequences, adr.consequences);
    }

    @Override
    public int hashCode() {
        return Objects.hash(Id, title, status, context, consequences);
    }
}
