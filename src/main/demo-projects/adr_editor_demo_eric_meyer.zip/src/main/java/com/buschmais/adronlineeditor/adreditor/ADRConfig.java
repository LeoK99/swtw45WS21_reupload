package com.buschmais.adronlineeditor.adreditor;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.CommandLineRunner;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

import java.util.List;

@Configuration
public class ADRConfig {

    @Autowired
    @Bean
    CommandLineRunner commandLineRunner(ADRRepository adrRepository){
        return args -> {
            ADR adr1 = new ADR("Example 1", ADRStatus.PROPOSED.getStatus(), "This is a proposed adr!", "Nothing!");
            ADR adr2 = new ADR("Example 2", ADRStatus.PROPOSED.getStatus(), "This is not a proposed adr2!", "Really Nothing!");
            adrRepository.saveAll(List.of(adr1, adr2));
        };
    }
}
