package com.buschmais.adronlineeditor.adreditor;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Bean;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping(path = "api/v1/adrs")
public class ADRController {

    private final ADRService adrService;

    @Autowired
    public ADRController(ADRService adrService) {
        this.adrService = adrService;
    }

    @GetMapping("/list")
    public List<ADR> getADRs() {
        return adrService.getADRs();
    }

    @GetMapping("/list/{adrId}")
    public ADR getADR(@PathVariable("adrId") Long adrId) {
        return adrService.getADR(adrId);
    }

    @DeleteMapping(path = "{adrId}")
    public void deleteADR(@PathVariable("adrId") Long Id) {
        this.adrService.deleteADR(Id);
    }

    @PostMapping
    public void createNewADR(@RequestBody ADR adr) {
        adrService.addNewADR(adr);
    }

    @PutMapping(path = "{adrId}")
    public void updateADR(
            @PathVariable("adrId") Long id,
            @RequestParam(required = false) String title,
            @RequestParam(required = false) int status,
            @RequestParam(required = false) String context,
            @RequestParam(required = false) String consequences) {
        adrService.updateADR(id, title, status, context, consequences);
    }

    // Utils
    public int convertStatusStringToInt(String status) {

        int returnValue = ADRStatus.UNKNOWN.getStatus();
        switch (status.toLowerCase()) {
            case "proposed":
                returnValue = ADRStatus.PROPOSED.getStatus();
            break;
            case "accepted":
                returnValue = 2;
            break;
            case "superseded":
                returnValue = ADRStatus.SUPERSEDED.getStatus();
                break;
            case "declined":
                returnValue = ADRStatus.DECLINED.getStatus();
                break;
            default:
        }

        return returnValue;
    }


}
