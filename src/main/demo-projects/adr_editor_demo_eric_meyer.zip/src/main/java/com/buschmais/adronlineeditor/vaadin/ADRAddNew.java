package com.buschmais.adronlineeditor.vaadin;

import com.buschmais.adronlineeditor.adreditor.ADR;
import com.buschmais.adronlineeditor.adreditor.ADRController;
import com.vaadin.flow.component.ClickEvent;
import com.vaadin.flow.component.ComponentEventListener;
import com.vaadin.flow.component.button.Button;
import com.vaadin.flow.component.html.Div;
import com.vaadin.flow.component.html.H2;
import com.vaadin.flow.component.html.H3;
import com.vaadin.flow.component.notification.Notification;
import com.vaadin.flow.component.orderedlayout.FlexComponent;
import com.vaadin.flow.component.orderedlayout.HorizontalLayout;
import com.vaadin.flow.component.orderedlayout.VerticalLayout;
import com.vaadin.flow.component.textfield.TextArea;
import com.vaadin.flow.component.textfield.TextField;
import com.vaadin.flow.router.Route;

@Route("addnewadr")
public class ADRAddNew extends Div {

    private final ADRController adrController;

    private VerticalLayout layoutHeading;
    private VerticalLayout layoutLeftTable;
    private VerticalLayout layoutRightTable;
    private HorizontalLayout layoutTable;

    private TextField titleField;
    private TextField statusField;

    private TextArea contextArea;
    private TextArea consequenceArea;

    private String buttonWidth = "400px";

    private Button send;

    public ADRAddNew(ADRController adrController) {
        this.adrController = adrController;

        layoutHeading = new VerticalLayout();
        layoutLeftTable = new VerticalLayout();
        layoutRightTable = new VerticalLayout();

        addLayouts();
    }

    private void addLayouts() {
        setComponentsLayoutHeading();
        layoutHeading.setAlignItems(FlexComponent.Alignment.CENTER);
        add(this.layoutHeading);

        setComponentsLayoutLeftTable();
        setComponentsLayoutRightTable();

        this.layoutRightTable.setAlignItems(FlexComponent.Alignment.CENTER);


        layoutTable = new HorizontalLayout(this.layoutLeftTable, this.layoutRightTable);
        add(layoutTable);
    }

    private void setComponentsLayoutHeading() {
        H2 heading = new H2("Erstellen eines neuen Architecture Decision Record");
        this.layoutHeading.add(heading);
    }

    private void setComponentsLayoutLeftTable() {

        titleField = new TextField("Titel");
        titleField.setPlaceholder("Example Title");
        titleField.setWidth("400px");

        statusField = new TextField("Status");
        statusField.setPlaceholder("Example Status");
        statusField.setWidth("400px");

        contextArea = new TextArea("Kontext");
        contextArea.setPlaceholder("Example Context");
        contextArea.setWidth("750px");
        contextArea.setHeight("200px");

        consequenceArea = new TextArea("Konsequenzen");
        consequenceArea.setPlaceholder("Example Consequences");
        consequenceArea.setWidth("750px");
        consequenceArea.setHeight("200px");


        this.layoutLeftTable.add(titleField);
        this.layoutLeftTable.add(statusField);
        this.layoutLeftTable.add(contextArea);
        this.layoutLeftTable.add(consequenceArea);

    }

    private void setComponentsLayoutRightTable() {

        /* Send-Button */
        send = new Button("Erstellen");
        send.setWidth("350px");
        send.setHeight("75px");

        // Action-Listener
        send.addClickListener(new ComponentEventListener<ClickEvent<Button>>() {
            @Override
            public void onComponentEvent(ClickEvent<Button> buttonClickEvent) {
                boolean readyToSend = true;

                if (titleField.getValue().trim().isEmpty()) {
                    Notification.show(titleField.getLabel() + " wurde nicht ausgefüllt!");
                    readyToSend = false;
                }
                if (statusField.getValue().trim().isEmpty()) {
                    Notification.show(statusField.getLabel() + " wurde nicht ausgefüllt!");
                    readyToSend = false;
                }
                if (contextArea.getValue().trim().isEmpty()) {
                    Notification.show(contextArea.getLabel() + " wurde nicht ausgefüllt!");
                    readyToSend = false;
                }
                if (consequenceArea.getValue().trim().isEmpty()) {
                    Notification.show(consequenceArea.getLabel() + " wurde nicht ausgefüllt!");
                    readyToSend = false;
                }

                if (readyToSend) {
                    ADR newADR = new ADR(titleField.getValue(), adrController.convertStatusStringToInt(statusField.getValue()), contextArea.getValue(), consequenceArea.getValue());
                    adrController.createNewADR(newADR);
                    Notification.show("ADR wurde erfolgreich erstellt!");
                }

            }
        });

        /* Navigation-Buttons */
        Button home = new Button("Home");
        Button adrList = new Button("ADR-Liste");
        Button deleteADR = new Button("ADR löschen");

        home.setWidth(this.buttonWidth);
        adrList.setWidth(this.buttonWidth);
        deleteADR.setWidth(this.buttonWidth);

        // ActionListener
        home.addClickListener(new ComponentEventListener<ClickEvent<Button>>() {
            @Override
            public void onComponentEvent(ClickEvent<Button> buttonClickEvent) {
                home.getUI().get().navigate("");
            }
        });

        adrList.addClickListener(new ComponentEventListener<ClickEvent<Button>>() {
            @Override
            public void onComponentEvent(ClickEvent<Button> buttonClickEvent) {
                adrList.getUI().get().navigate("adrlist");
            }
        });

        deleteADR.addClickListener(new ComponentEventListener<ClickEvent<Button>>() {
            @Override
            public void onComponentEvent(ClickEvent<Button> buttonClickEvent) {
                deleteADR.getUI().get().navigate("deleteadr");
            }
        });

        /* Adding Components to Left Table */
        this.layoutLeftTable.add(send);

        // Heading
        H3 navigationLabel = new H3("Navigation");

        /* Adding Components to Right Table */
        this.layoutRightTable.add(navigationLabel);
        this.layoutRightTable.add(home);
        this.layoutRightTable.add(adrList);
        this.layoutRightTable.add(deleteADR);
    }


}
