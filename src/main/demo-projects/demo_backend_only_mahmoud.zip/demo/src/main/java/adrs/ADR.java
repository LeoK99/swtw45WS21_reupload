package adrs;

import org.springframework.lang.NonNull;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import java.util.Objects;

@Entity
public class ADR {
    @Id @GeneratedValue private Long id;
    private String content;

    public ADR(){}
    public ADR(String initialContent){
        content = initialContent;
    }

    public void setContent(@NonNull String content){
        this.content = content;
    }

    public String getContent(){
        return content;
    }

    public Long getId(){
        return id;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        ADR adr = (ADR) o;
        return Objects.equals(id, adr.id);
    }

    @Override
    public int hashCode() {
        return Objects.hash(id, content);
    }
}
