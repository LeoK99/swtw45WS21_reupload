package adrs;

import org.springframework.hateoas.EntityModel;
import org.springframework.hateoas.server.RepresentationModelAssembler;
import org.springframework.stereotype.Component;

import static org.springframework.hateoas.server.mvc.WebMvcLinkBuilder.linkTo;
import static org.springframework.hateoas.server.mvc.WebMvcLinkBuilder.methodOn;

@Component
public class ADRModelAssembler implements RepresentationModelAssembler<ADR, EntityModel<ADR>> {

    @Override
    public EntityModel<ADR> toModel(ADR entity) {
        return EntityModel.of(entity,
                linkTo(methodOn(ADRController.class).one(entity.getId())).withSelfRel(),
                linkTo(methodOn(UserController.class).all()).withRel("adrs"));
    }
}
