package adrs;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.boot.CommandLineRunner;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

@Configuration
class LoadDatabase {

    private static final Logger log = LoggerFactory.getLogger(LoadDatabase.class);

    @Bean
    CommandLineRunner initDatabase(
            UserRepository userRepository,
            ADRRepository adrRepository) {

        var adr1 = adrRepository.save(new ADR("Adr 1"));
        var adr2 = adrRepository.save(new ADR("Adr 2"));

        var user1 = userRepository.save(new User("user1"));
        var user2 = userRepository.save(new User("user2"));
        user1.addADR(adr1.getId());
        user2.addADR(adr2.getId());
        userRepository.save(user1);
        userRepository.save(user2);
        
        return args -> {
            log.info("Preloading " + user1);
            log.info("Preloading " + user2);
        };
    }
}