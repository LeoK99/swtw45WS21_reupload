package adrs;

import java.util.ArrayList;
import java.util.List;
import java.util.Objects;

import javax.persistence.ElementCollection;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;

@Entity
class User {

    private @Id @GeneratedValue Long id;
    private String name;

    @ElementCollection
    private List<Long> ownedADRs;

    public User() {}

    User(String name) {
        this.name = name;
        this.ownedADRs = new ArrayList<Long>();
    }

    public String getName() {
        return this.name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public boolean addADR(Long adr_id) {
        return ownedADRs.add(adr_id);
    }

    public List<Long> getOwnedADRs() {
        return this.ownedADRs;
    }

    public Long getId() {
        return this.id;
    }

    @Override
    public boolean equals(Object o) {

        if (this == o)
            return true;
        if (!(o instanceof User))
            return false;
        User user = (User) o;
        return Objects.equals(this.id, user.id);
    }

    @Override
    public int hashCode() {
        return Objects.hash(this.id);
    }

    @Override
    public String toString() {
        return String.format(
                "User{id=%d, Name=%s, ADRs=[%s]}",
                id,
                name,
                ownedADRs.stream()
                        .map(Object::toString)
                        .reduce((s1, s2) -> s1+ ", " + s2)
                        .orElse("")
        );
    }
}