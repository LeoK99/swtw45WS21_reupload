package adrs;

import org.springframework.data.jpa.repository.JpaRepository;

public interface ADRRepository extends JpaRepository<ADR, Long> {
}
