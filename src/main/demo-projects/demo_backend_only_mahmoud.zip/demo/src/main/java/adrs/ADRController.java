package adrs;

import org.springframework.hateoas.CollectionModel;
import org.springframework.hateoas.EntityModel;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;

import java.util.List;
import java.util.stream.Collectors;

import static org.springframework.hateoas.server.mvc.WebMvcLinkBuilder.linkTo;
import static org.springframework.hateoas.server.mvc.WebMvcLinkBuilder.methodOn;

@Controller
@CrossOrigin("*") // Change later
public class ADRController {
    private final ADRRepository adrRepository;
    private final ADRModelAssembler adrModelAssembler;

    public ADRRepository getAdrRepository() {
        return adrRepository;
    }

    public ADRModelAssembler getAdrModelAssembler() {
        return adrModelAssembler;
    }

    public ADRController(ADRRepository adrRepository, ADRModelAssembler adrModelAssembler) {
        this.adrRepository = adrRepository;
        this.adrModelAssembler = adrModelAssembler;
    }

    // Aggregate root
    // tag::get-aggregate-root[]
    @GetMapping("/adrs")
    CollectionModel<EntityModel<ADR>> all() {

        List<EntityModel<ADR>> adrs = adrRepository.findAll().stream()
                .map(adrModelAssembler::toModel)
                .collect(Collectors.toList());

        return CollectionModel.of(adrs,
                linkTo(methodOn(ADRController.class).all()).withSelfRel()
        );
    }
    // end::get-aggregate-root[]

    @GetMapping("/adr/{id}")
    EntityModel<ADR> one(@PathVariable Long id) {

        ADR adr = adrRepository.findById(id) //
                .orElseThrow(() -> new UserNotFoundException(id));

        return adrModelAssembler.toModel(adr);
    }
}
