package adrs;

import java.util.List;
import java.util.NoSuchElementException;
import java.util.stream.Collectors;

import org.springframework.hateoas.CollectionModel;
import org.springframework.hateoas.EntityModel;
import org.springframework.hateoas.IanaLinkRelations;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import static org.springframework.hateoas.server.mvc.WebMvcLinkBuilder.linkTo;
import static org.springframework.hateoas.server.mvc.WebMvcLinkBuilder.methodOn;

@RestController
@CrossOrigin("*") // Change later
class UserController {

    private final UserRepository userRepository;
    private final ADRController adrController;

    private final UserModelAssembler userModelAssembler;

    UserController(
            UserRepository userRepository,
            ADRController adrController,
            UserModelAssembler assembler
    )
    {
        this.adrController = adrController;
        this.userRepository = userRepository;
        this.userModelAssembler = assembler;
    }


    // Aggregate root
    // tag::get-aggregate-root[]
    @GetMapping("/users")
    CollectionModel<EntityModel<User>> all() {

        List<EntityModel<User>> users = userRepository.findAll().stream() //
                .map(userModelAssembler::toModel) //
                .collect(Collectors.toList());

        return CollectionModel.of(users, linkTo(methodOn(UserController.class).all()).withSelfRel());
    }
    // end::get-aggregate-root[]

    @PostMapping("/user")
    ResponseEntity<?> newOne(@RequestBody User newUser) {
        EntityModel<User> entityModel = userModelAssembler.toModel(userRepository.save(newUser));

        return ResponseEntity //
                .created(entityModel.getRequiredLink(IanaLinkRelations.SELF).toUri()) //
                .body(entityModel);
    }

    // Single item
    @GetMapping("/user/{id}")
    EntityModel<User> one(@PathVariable Long id) {

        User user = userRepository.findById(id) //
                .orElseThrow(() -> new UserNotFoundException(id));

        return userModelAssembler.toModel(user);
    }

    @DeleteMapping("/user/{id}")
    ResponseEntity<?> deleteOne(@PathVariable Long id) {

        userRepository.deleteById(id);

        return ResponseEntity.noContent().build();
    }

    @PutMapping("/user/{id}/adr")
    ResponseEntity<?> createADR(@PathVariable Long id) {
        User updatedUser = userRepository.findById(id) //
                .map(user -> {
                    ADR adr = new ADR();
                    adr = adrController.getAdrRepository().save(adr);
                    user.getOwnedADRs().add(adr.getId());
                    return userRepository.save(user);
                }) //
                .orElseThrow(() -> {throw new UserNotFoundException(id);});

        EntityModel<User> entityModel = userModelAssembler.toModel(updatedUser);

        return ResponseEntity //
                .created(entityModel.getRequiredLink(IanaLinkRelations.SELF).toUri()) //
                .body(entityModel);
    }

    @GetMapping("/user/{id}/adr/{adrId}")
    ResponseEntity<?> getADR(@PathVariable Long id, @PathVariable Long adrId) {
        ADR adr = userRepository.findById(id) //
                .map(user -> {
                    Long foundAdrid = user.getOwnedADRs()
                            .stream()
                            .filter(ele -> ele.equals(adrId))
                            .findFirst()
                            .orElseThrow(() -> new NoSuchElementException("Adr not found"));

                    return adrController.getAdrRepository().findById(foundAdrid).orElseThrow(() -> new IllegalStateException("Sync Error"));
                }) //
                .orElseThrow(() -> {throw new UserNotFoundException(id);});

        EntityModel<ADR> entityModel = adrController.getAdrModelAssembler().toModel(adr);

        return ResponseEntity //
                .created(entityModel.getRequiredLink(IanaLinkRelations.SELF).toUri()) //
                .body(entityModel);
    }
}