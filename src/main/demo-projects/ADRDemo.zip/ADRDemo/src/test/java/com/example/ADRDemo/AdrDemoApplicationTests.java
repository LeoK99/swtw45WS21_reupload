package com.example.ADRDemo;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class AdrDemoApplicationTests {

	@Test
	void contextLoads() {
	}

}
