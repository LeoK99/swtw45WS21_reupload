package com.example.ADRDemo;

import com.vaadin.flow.component.Key;
import com.vaadin.flow.component.KeyNotifier;
import com.vaadin.flow.component.button.Button;

import com.vaadin.flow.component.html.Label;
import com.vaadin.flow.component.icon.VaadinIcon;
import com.vaadin.flow.component.orderedlayout.HorizontalLayout;
import com.vaadin.flow.component.orderedlayout.VerticalLayout;
import com.vaadin.flow.component.listbox.ListBox;
import com.vaadin.flow.component.textfield.TextField;
import com.vaadin.flow.data.binder.Binder;
import com.vaadin.flow.spring.annotation.SpringComponent;
import com.vaadin.flow.spring.annotation.UIScope;

import org.springframework.beans.factory.annotation.Autowired;

@SpringComponent
@UIScope

public class ADREditor extends VerticalLayout implements KeyNotifier {

    private final ADRRepository repo;

    private ADR adr; //adr thats eddited


    ListBox<Stat> Status = new ListBox<>();








    TextField Context = new TextField("Context");
    TextField Decision = new TextField("Decision");
    TextField Consequences = new TextField("Consequences");

    Button save = new Button("Save", VaadinIcon.CHECK.create());
    Button cancel = new Button("Cancel");
    Button delete = new Button("Delete", VaadinIcon.TRASH.create());
    HorizontalLayout actions = new HorizontalLayout(save, cancel, delete);

    Binder<ADR> binder = new Binder<>(ADR.class);
    private ChangeHandler changeHandler;
    @Autowired
    public ADREditor(ADRRepository repo){


        this.repo = repo;


        Context.setHeight("300px");
        Context.setWidth("600px");

        Decision.setHeight("300px");
        Decision.setWidth("600px");

        Consequences.setHeight("300px");
        Consequences.setWidth("600px");


        Status.setItems(Stat.In_Edit,Stat.Proposed,Stat.Accepted,Stat.Rejected,Stat.Superseeded);




        add(Status, Context,Decision,Consequences,actions);

        binder.bindInstanceFields(this);

       // binder.forField(Status).bind(ADR::getStatus,ADR::setStatus); I had some isues with binding to the Status when it still was an Stirng Array but switching to Enum mmade it work

        setSpacing(true);

        save.getElement().getThemeList().add("primary");
        delete.getElement().getThemeList().add("error");

        //addKeyPressListener(Key.ENTER, e -> save());
        // wire action buttons to save, delete and reset
        save.addClickListener(e -> save());
        delete.addClickListener(e -> delete());
        cancel.addClickListener(e -> editADR(adr));




        setVisible(false);
    }



    void delete(){
        repo.delete(adr);
        changeHandler.onChange();
    }

    void save(){
        repo.save(adr);
        changeHandler.onChange();
    }

    public interface ChangeHandler{
        void onChange();
    }

    public final void editADR(ADR a){
        if(a==null){
            setVisible(false);
            return;
        }


        final boolean presisted = a.getId() != null;

        if(presisted){
                adr = repo.findById(a.getId()).get();
        }else{
            adr = a;
        }
        cancel.setVisible(presisted);
        Status.setVisible(true);

        // Bind customer properties to similarly named field
        // Could also use annotation or "manual binding" or programmatically
        // moving values from fields to entities before saving

        binder.setBean(adr);

        setVisible(true);

        Context.focus();
    }

    public void setChangeHandler(ChangeHandler h){
        changeHandler = h;
    }
}
