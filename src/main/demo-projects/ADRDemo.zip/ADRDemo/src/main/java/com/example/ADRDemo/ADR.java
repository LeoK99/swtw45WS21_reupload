package com.example.ADRDemo;

import org.springframework.boot.autoconfigure.domain.EntityScan;

import java.util.Objects;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;



@Entity
public class ADR {


    private @Id @GeneratedValue Long id;
    private Stat Status;
    private String Context;
    private String Decision;
    private String Consequences;


    public ADR(Stat status, String context, String decision, String consequences) {
        Status = status;
        Context = context;
        Decision = decision;
        Consequences = consequences;
    }

    public ADR(){

    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        ADR adr = (ADR) o;
        return Status == adr.Status && id.equals(adr.id) && Context.equals(adr.Context) && Decision.equals(adr.Decision) && Consequences.equals(adr.Consequences);
    }

    @Override
    public int hashCode() {
        return Objects.hash(id, Status, Context, Decision, Consequences);
    }

    @Override
    public String toString() {
        return "ADR{" +
                "id=" + id +
                ", Status=" + Status +
                ", Context='" + Context + '\'' +
                ", Decision='" + Decision + '\'' +
                ", Consequences='" + Consequences + '\'' +
                '}';
    }

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }


    public void setStatus(Stat status) {
        Status = status;
    }

    public Stat getStatus(){
        return Status;
    }

    public String getContext() {
        return Context;
    }

    public void setContext(String context) {
        Context = context;
    }

    public String getDecision() {
        return Decision;
    }

    public void setDecision(String decision) {
        Decision = decision;
    }

    public String getConsequences() {
        return Consequences;
    }

    public void setConsequences(String consequences) {
        Consequences = consequences;
    }
}
