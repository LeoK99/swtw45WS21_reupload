package com.example.ADRDemo;

import com.vaadin.flow.component.button.Button;
import com.vaadin.flow.component.grid.Grid;
import com.vaadin.flow.component.icon.VaadinIcon;
import com.vaadin.flow.component.orderedlayout.HorizontalLayout;
import com.vaadin.flow.component.orderedlayout.VerticalLayout;
import com.vaadin.flow.component.textfield.TextField;
import com.vaadin.flow.data.value.ValueChangeMode;
import com.vaadin.flow.router.Route;
import com.vaadin.flow.spring.annotation.UIScope;
import org.springframework.util.StringUtils;

@Route
public class MainView extends VerticalLayout {

    private final ADRRepository repo;

    private final ADREditor editor;

    final Grid<ADR> grid;;

    private final Button addNewBtn;


    public MainView(ADRRepository repo, ADREditor editor) {
        this.repo = repo;
        this.editor = editor;
        this.grid = new Grid<>(ADR.class);
        this.addNewBtn = new Button("New ADR", VaadinIcon.PLUS.create());

        //build layout

        HorizontalLayout actions = new HorizontalLayout(addNewBtn);


        add(actions,grid, editor);

        grid.setHeight("300px");
        //grid.setColumns("Consequences", "Context","Decs","id","Status");

        grid.asSingleSelect().addValueChangeListener( e -> {
            editor.editADR(e.getValue());
        });

        addNewBtn.addClickListener(e -> editor.editADR(new ADR(Stat.In_Edit, "","","")));

        editor.setChangeHandler(()-> {
            editor.setVisible(false);
            listADR();
        });


        listADR();
    }

    private void listADR() {
        grid.setItems(repo.findAll());
    }
}
