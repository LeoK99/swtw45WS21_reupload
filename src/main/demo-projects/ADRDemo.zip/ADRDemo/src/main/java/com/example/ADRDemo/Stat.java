package com.example.ADRDemo;


public enum Stat{
    In_Edit, Proposed, Accepted, Rejected, Superseeded;

}