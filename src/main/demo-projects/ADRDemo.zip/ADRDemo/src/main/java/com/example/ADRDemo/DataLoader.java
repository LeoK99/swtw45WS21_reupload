package com.example.ADRDemo;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.CommandLineRunner;
import org.springframework.stereotype.Component;

@Component

public class DataLoader implements CommandLineRunner {

    private final ADRRepository repo;

    @Autowired
    public DataLoader(ADRRepository repo){
        this.repo = repo;
    }


    @Override
    public void run(String... strings) throws Exception {
            this.repo.save(new ADR( Stat.In_Edit, "This is very Important cuz you know Stuff","DO MOAR BETTAR STUFF","PROFIT!"));
    }
}
