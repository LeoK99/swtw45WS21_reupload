package com.example.ADRDemo;

import com.vaadin.flow.component.button.Button;
import com.vaadin.flow.component.orderedlayout.HorizontalLayout;
import com.vaadin.flow.component.textfield.TextField;

public class TextEditor extends TextField{


    Button Bold =new Button("\b b");

    public TextEditor(String label, String width, String  height){
        super(label);
        this.setHeight(height);
        this.setWidth(width);
    }

}
