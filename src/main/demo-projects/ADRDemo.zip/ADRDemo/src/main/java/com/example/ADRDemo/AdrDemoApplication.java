package com.example.ADRDemo;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class AdrDemoApplication {

	public static void main(String[] args) {
		SpringApplication.run(AdrDemoApplication.class, args);
	}

}


/*
TODO:
Cutomizable Forntend thats more then jus the default Vaadin Components
Have a "Frontpage"
Proper Editorfields rather then just Textfield
 */
