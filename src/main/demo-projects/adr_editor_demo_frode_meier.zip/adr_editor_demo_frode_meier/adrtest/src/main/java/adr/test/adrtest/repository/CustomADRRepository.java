package adr.test.adrtest.repository;

import adr.test.adrtest.ADR.ADR;

import java.util.List;

public interface CustomADRRepository {

    public List<ADR> getAll();
    public ADR getByTitle(String Title);
    public List<ADR> getByStatus(int status);

    public void createADR(ADR adr);
    public ADR changeContext(String title, String context);
    public boolean delete(String title);
    public void deleteAll();

}
