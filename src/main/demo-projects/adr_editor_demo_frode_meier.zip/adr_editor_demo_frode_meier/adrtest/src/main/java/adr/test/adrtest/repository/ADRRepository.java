package adr.test.adrtest.repository;

import adr.test.adrtest.ADR.ADR;
import org.springframework.data.mongodb.repository.MongoRepository;
import org.springframework.data.mongodb.repository.Query;

import java.util.List;
import java.util.stream.Stream;

public interface ADRRepository extends MongoRepository<ADR, String> {

    @Query("{title : ?0}")
    ADR findByTitle(String title);

    @Query(value = "{status : ?0}", fields = "{ 'title' : 1, 'context' : 1}")
    List<ADR> findByStatus(int status);

    public long count();
}
