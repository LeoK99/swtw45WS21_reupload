package adr.test.adrtest.repository;

import adr.test.adrtest.ADR.ADR;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.stereotype.Repository;
import org.springframework.web.bind.annotation.RestController;

import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;
import java.util.stream.Stream;

@Repository
public class CustomADRRepositoryImpl implements CustomADRRepository{

    @Autowired
    private ADRRepository repo;


    @Override
    public List<ADR> getAll() {
        repo.findAll().forEach(adr -> System.out.println(adr));
        return repo.findAll();
    }

    @Override
    public ADR getByTitle(String title) {
        System.out.println(repo.findByTitle(title));
        return repo.findByTitle(title);
    }

    @Override
    public List<ADR> getByStatus(int status) {
        System.out.println(status);
        List<ADR> adrs = repo.findByStatus(status);
        System.out.println(adrs);
        return adrs;
    }


    @Override
    public void createADR(ADR adr) {
        repo.insert(adr);
    }


    @Override
    public ADR changeContext(String title, String context) {
        ADR adr = this.getByTitle(title);
        adr.setContext(context);

        System.out.println(adr);

        return repo.save(adr);
    }


    @Override
    public boolean delete(String title) {
        ADR adr = repo.findByTitle(title);
        if(adr != null) {
            repo.deleteById(adr.getId());
            return true;
        }
        else return false;
    }

    @Override
    public void deleteAll() {
        repo.deleteAll();
    }
}

//public class CustomItemRepositoryImpl implements CustomItemRepository {
//
//    @Autowired
//    MongoTemplate mongoTemplate;
//
//    public void updateItemQuantity(String name, float newQuantity) {
//        Query query = new Query(Criteria.where("name").is(name));
//        Update update = new Update();
//        update.set("quantity", newQuantity);
//
//        UpdateResult result = mongoTemplate.updateFirst(query, update, GroceryItem.class);
//
//        if(result == null)
//            System.out.println("No documents updated");
//        else
//            System.out.println(result.getModifiedCount() + " document(s) updated..");
//
//    }
//
//}
