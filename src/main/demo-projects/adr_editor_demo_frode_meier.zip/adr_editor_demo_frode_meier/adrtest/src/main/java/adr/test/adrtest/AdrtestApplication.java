package adr.test.adrtest;

import adr.test.adrtest.ADR.ADR;
import adr.test.adrtest.repository.ADRRepository;
import adr.test.adrtest.repository.CustomADRRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.CommandLineRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.data.mongodb.repository.config.EnableMongoRepositories;

import java.util.ArrayList;
import java.util.List;

@SpringBootApplication
@EnableMongoRepositories
public class AdrtestApplication implements CommandLineRunner {

	@Autowired
	CustomADRRepository repo;

	public static void main(String[] args) {
		SpringApplication.run(AdrtestApplication.class, args);
	}

	@Override
	public void run(String... args) throws Exception {

		repo.deleteAll();

		System.out.println("---------------------Create ADRs---------------------\n");

		repo.createADR(new ADR("Example", "context", "decision", 1, "consequences"));
		repo.createADR(new ADR("Example2", "context2", "decision2", 1, "consequences2"));
		repo.createADR(new ADR("Example3", "context3", "decision3", 3, "consequences3"));

		System.out.println("--------------------Show all ADRs--------------------\n");

		repo.getAll().forEach(adr -> {System.out.println("\n" + adr);});

		System.out.println("--------------------Show ADR by ID-------------------\n");

		repo.getByTitle("Example");

		System.out.println("---------------Show all ADRs by Status---------------\n");

		repo.getByStatus(1).forEach(adr -> {
			System.out.println("Title: " + adr.getTitle() + ", Context: " + adr.getContext());
		});

		System.out.println("---------------Show all ADRs by Status---------------\n");

		repo.changeContext("Example2", "ABX");
		repo.getByTitle("Example2");

		System.out.println("---------------Show all ADRs by Status---------------\n");

		System.out.println(repo.delete("example"));
	}
}
