package adr.test.adrtest.ADR;

import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class ADRService {

    public List<ADR> getAnADR() {
        return List.of(
                new ADR(
                        "FirstADR",
                        "first test",
                        "decision",
                        1,
                        "consequenz"
                )
        );
    }

}
