package adr.test.adrtest.ADR;

import adr.test.adrtest.repository.CustomADRRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@CrossOrigin(origins = "http://localhost:4200")
@RequestMapping(path = "v1/ADR")
public class ADRController {

    @Autowired
    CustomADRRepository repo;

    private final ADRService adrService;

    @Autowired
    public ADRController(ADRService adrService) {
        this.adrService = adrService;
    }

    @GetMapping("/adr")
    public List<ADR> getADRs() {
        return repo.getAll();
    }

    @PostMapping("/adr")
    public void addADR(@RequestBody ADR adr) {

        repo.createADR(adr);

    }

}
