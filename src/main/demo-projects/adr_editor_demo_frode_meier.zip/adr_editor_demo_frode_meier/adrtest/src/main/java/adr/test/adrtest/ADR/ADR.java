package adr.test.adrtest.ADR;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.mapping.Document;

@Document("ADR")
public class ADR {

    @Id
    private String id;
    private String title;
    private String context;
    private String decision;
    private int status;
    private String consequences;

    public static final int st_New = 0, st_Proposed = 1, st_Accepted = 2, st_Superseded = 3, st_Declined = 4;

    @Autowired
    public ADR(String title, String context, String decision, Integer status, String consequences) {
        super();
        this.title = title;
        this.context = context;
        this.decision = decision;

        if(status != null)
            this.status = status;

        this.consequences = consequences;
    }

    public String getId() { return id; }

    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public String getContext() {
        return context;
    }

    public void setContext(String context) {
        this.context = context;
    }

    public String getDecision() {
        return decision;
    }

    public void setDecision(String decision) {
        this.decision = decision;
    }

    public int getStatus() {
        return status;
    }

    public void setStatus(int status) { this.status = status; }

    public String getConsequences() {
        return consequences;
    }

    public void setConsequences(String consequences) {
        this.consequences = consequences;
    }


    @Override
    public String toString() {
        return "ADR{" +
                "id=" + id +
                ", title='" + title + '\'' +
                ", context='" + context + '\'' +
                ", decision='" + decision + '\'' +
                ", status=" + status +
                ", consequences='" + consequences + '\'' +
                '}';
    }



}


