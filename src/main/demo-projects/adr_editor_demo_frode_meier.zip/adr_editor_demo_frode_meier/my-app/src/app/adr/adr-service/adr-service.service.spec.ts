import { TestBed } from '@angular/core/testing';

import { AdrServiceService } from './adr-service.service';

describe('AdrServiceService', () => {
  let service: AdrServiceService;

  beforeEach(() => {
    TestBed.configureTestingModule({});
    service = TestBed.inject(AdrServiceService);
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });
});
