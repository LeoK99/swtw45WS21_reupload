import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { AdrFormComponent } from './adr/adr-form/adr-form.component';
import { AdrListComponent } from './adr/adr-list/adr-list.component';

const routes: Routes = [
  { path: 'all-adr', component: AdrListComponent },
  { path: 'new-adr', component: AdrFormComponent }
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
