import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import Adr from '../adr';
import { Observable } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class AdrServiceService {
  private AdrUrl: string;

  constructor(private http: HttpClient) {
    this.AdrUrl = 'http://localhost:8080/v1/ADR/adr';
  }

  public findAll(): Observable<Adr[]> {
    return this.http.get<Adr[]>(this.AdrUrl);
  }

  public save(adr: Adr) {
    return this.http.post<Adr>(this.AdrUrl, adr);
  }
}
