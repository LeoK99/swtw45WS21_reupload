
export default class Adr {
  id!: number;
  title!: string;
  context!: string;
  decision!: string;
  status!: number;
  consequences!: string;
}
