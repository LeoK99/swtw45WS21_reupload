import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import Adr from '../adr';
import { AdrServiceService } from '../adr-service/adr-service.service';

@Component({
  selector: 'app-adr-form',
  templateUrl: './adr-form.component.html',
  styleUrls: ['./adr-form.component.css']
})
export class AdrFormComponent {

  adr!:Adr;

  constructor(
    private route: ActivatedRoute,
    private router: Router,
    private adrService: AdrServiceService
  ) {
    this.adr = new Adr();
  }

  onSubmit() {
    this.adrService.save(this.adr).subscribe(result => this.gotoAdrList());
  }

  gotoAdrList() {
    this.router.navigate(['/users']);
  }

}
