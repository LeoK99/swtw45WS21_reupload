import { Component, OnInit } from '@angular/core';
import Adr from '../adr';
import { AdrServiceService } from '../adr-service/adr-service.service'

@Component({
  selector: 'app-adr-list',
  templateUrl: './adr-list.component.html',
  styleUrls: ['./adr-list.component.css']
})
export class AdrListComponent implements OnInit {

  adrs!: Adr[];

  constructor(private adrService: AdrServiceService) { }

  ngOnInit(): void {
    this.adrService.findAll().subscribe(arg => {this.adrs = arg;});
  }

}
