import { ComponentFixture, TestBed } from '@angular/core/testing';

import { AdrFormComponent } from './adr-form.component';

describe('AdrFormComponent', () => {
  let component: AdrFormComponent;
  let fixture: ComponentFixture<AdrFormComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ AdrFormComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(AdrFormComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
