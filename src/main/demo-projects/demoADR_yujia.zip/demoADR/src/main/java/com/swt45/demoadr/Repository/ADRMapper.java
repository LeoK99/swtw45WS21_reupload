package com.swt45.demoadr.Repository;

import com.swt45.demoadr.pojo.ADR;
import com.swt45.demoadr.pojo.User;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Param;
import org.springframework.stereotype.Repository;

@Mapper
@Repository
public interface ADRMapper {
    ADR create(@Param("id") String id, @Param("context") String context, @Param("decision") String decision, @Param("consequence") String consequence);
    void editcontext(@Param("id") String id, @Param("context") String context);
    ADR delete(@Param("id") String id);
}
