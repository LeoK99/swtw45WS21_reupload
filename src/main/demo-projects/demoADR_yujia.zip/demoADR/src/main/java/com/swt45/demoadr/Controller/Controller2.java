package com.swt45.demoadr.Controller;

import com.swt45.demoadr.Service.UserLoginService;
import com.swt45.demoadr.pojo.User;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;

import javax.servlet.http.HttpServletRequest;

@Controller
@RequestMapping(value = {"/user"})
public class Controller2 {
    @Autowired
    private UserLoginService userLoginService;

    @RequestMapping(value = {"/login"})
    public String login(){
        return "login";
    }

    @RequestMapping(value = {"/register"})
    public String register(){
        return "register";
    }

    @RequestMapping(value = {"/loginn"})
    public String loginn(@RequestParam("id") String id, @RequestParam("password") String password, HttpServletRequest request){

        User user = userLoginService.login(id,password);

        if(user != null){
            request.getSession().setAttribute("session_user",user);
            return "loginsuccess";
        }
        return "loginfailed";
    }


    @ResponseBody
    @RequestMapping(value = {"/register"})
    public String addUser(@RequestParam("id") String id,
                          @RequestParam("password") String password,
                          @RequestParam("password2") String password2){

        if(!password.equals(password2)){

            return "Password must be the same!";
        }else {
            int res = userLoginService.adduser(id, password);
            if(res == 0){
                return "register failed";
            }else {
                return "register success";
            }
        }
    }
}
