package com.swt45.demoadr.Service;

import com.swt45.demoadr.Repository.ADRMapper;
import com.swt45.demoadr.Repository.UserMapper;
import com.swt45.demoadr.pojo.ADR;
import com.swt45.demoadr.pojo.Status;
import org.springframework.beans.factory.annotation.Autowired;

public class ADREditService {
    @Autowired
    private ADRMapper adrmapper;

    public ADR create(String id, String context, String decision, String consequence){
        ADR adr = adrmapper.create(id,context, decision, consequence);
        return adr;
    }
    public void editcontext(String id, String context){}
    public ADR delete(String id){
        ADR adr = adrmapper.delete(id);
        return adr;
    }
}
