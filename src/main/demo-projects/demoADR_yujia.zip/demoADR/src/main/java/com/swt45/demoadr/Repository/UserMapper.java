package com.swt45.demoadr.Repository;

import com.swt45.demoadr.pojo.User;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Param;
import org.springframework.stereotype.Repository;

@Mapper
@Repository
public interface UserMapper {
    User login(@Param("id") String id, @Param("password") String password);

    int adduser(@Param("id") String id, @Param("password") String password);

    int deleteuser(@Param("id") String id);
}
