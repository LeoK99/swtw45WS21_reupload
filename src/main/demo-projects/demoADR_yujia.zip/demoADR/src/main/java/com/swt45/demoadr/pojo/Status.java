package com.swt45.demoadr.pojo;

public enum Status {
    ACCEPTED, REJECTED, ONEDIT
}
