package com.swt45.demoadr.pojo;

import org.springframework.stereotype.Component;

@Component
public class ADR {
    private String id;
    private Status status;
    private String context;
    private String decision;
    private String consequence;

    public ADR(String id, String context, String decision, String consequence) {
        this.id = id;
        this.status = Status.ONEDIT;
        this.context = context;
        this.decision = decision;
        this.consequence = consequence;
    }

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public Status getStatus() {
        return status;
    }

    public void setStatus(Status status) {
        this.status = status;
    }

    public String getDecision() {
        return decision;
    }

    public void setDecision(String decision) {
        this.decision = decision;
    }

    public String getConsequence() {
        return consequence;
    }

    public void setConsequence(String consequence) {
        this.consequence = consequence;
    }

    public String getContext() {
        return context;
    }

    public void setContext(String context) {
        this.context = context;
    }

    @Override
    public String toString() {
        return "ADR{" +
                "id='" + id + '\'' +
                ", status=" + status +
                ", context='" + context + '\'' +
                ", decision='" + decision + '\'' +
                ", consequence='" + consequence + '\'' +
                '}';
    }
}
