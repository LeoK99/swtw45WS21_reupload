package com.swt45.demoadr;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class DemoAdrApplication {

    public static void main(String[] args) {
        SpringApplication.run(DemoAdrApplication.class, args);
    }

}
