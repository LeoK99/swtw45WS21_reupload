package com.swt45.demoadr.Controller;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;

@Controller

@RequestMapping(value = {"/ADR"})
public class Controller1 {
    @RequestMapping(value = {"/welcome"})
    public String welcome(){
        return "welcome";
    }
}
