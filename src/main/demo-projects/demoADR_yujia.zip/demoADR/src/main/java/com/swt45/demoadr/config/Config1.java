package com.swt45.demoadr.config;

import com.swt45.demoadr.pojo.ADR;
import com.swt45.demoadr.pojo.User;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.Configuration;

@Configuration
@ComponentScan("com.swt45.demoadr")
public class Config1 {
    @Bean
    public User user(){ return new User("user1","1234");}
    @Bean
    public ADR adr(){ return new ADR("zxcv123","abcdefg","lkjjhg","poiuy");}
}
