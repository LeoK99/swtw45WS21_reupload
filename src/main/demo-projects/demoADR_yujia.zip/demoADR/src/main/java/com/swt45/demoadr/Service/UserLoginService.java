package com.swt45.demoadr.Service;

import com.swt45.demoadr.pojo.User;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import com.swt45.demoadr.Repository.UserMapper;

@Service
public class UserLoginService {
    @Autowired
    private UserMapper usermapper;

    public User login(String id, String password){
        User user = usermapper.login(id,password);
        return user;
    }
    public int adduser(String id,String password){
        return usermapper.adduser(id,password);
    }
}
