package com.swt45.demoadr.pojo;

import org.springframework.stereotype.Component;

import java.util.Set;

@Component
public class User {
    private String id;
    private String password;
    private Set<ADR> adrs;

    public User(String id, String password) {
        this.id = id;
        this.password = password;
    }

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getPassword() {
        return password;
    }

    public void setPassword(String password) {
        this.password = password;
    }

    public Set<ADR> getAdrs() {
        return adrs;
    }

    public void addAdr(ADR adr){
        adrs.add(adr);
    }

    public void removeAdr(ADR adr){
        if(!adrs.contains(adr)){
            throw new IllegalArgumentException("Adr doesn't exit");
        }else{
            adrs.remove(adr);
        }
    }
}
